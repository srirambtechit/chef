package com.learning.academy.jms;

import java.io.IOException;

import javax.jms.Connection;
import javax.jms.MessageConsumer;
import javax.jms.MessageProducer;
import javax.jms.Queue;
import javax.jms.QueueConnectionFactory;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.learning.academy.jms.utility.Logger;

/**
 * Servlet implementation class Exercise1
 * 
 * @author nbrprakash
 */
@WebServlet("/Exercise1")
public class Exercise1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
	 private Logger logger = null;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Exercise1() {
        super();
        logger = new Logger("Exercise 1");
        System.out.println("test constructor");
    }
    
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append(logger.displayText());
		
		logger.log("Hello World.");
		
		try {
	        String text = "Message to be sent" ;
			
			Context ctx = new InitialContext();
			
			QueueConnectionFactory qcf = (QueueConnectionFactory) ctx.lookup("jms/Ex1QCF");
			response.getWriter().append("QCF JNDI Obtained.");
			
			Connection conn = qcf.createQueueConnection();
			logger.log("Connection Created.");
			
	        Session session = conn.createSession();
	        logger.log("Session Created.");
	        
	        Queue sendQueue = (Queue) ctx.lookup("jms/SendQueue");
	        logger.log("SendQueue JNDI Obtained.");
	        	        
	        conn.start();
	        logger.log("Connection Started.");
	        
	        TextMessage msg = session.createTextMessage("Message From Producer ->" + text);
	        logger.log("Text Message Created.");
	        
	        MessageProducer producer = session.createProducer(sendQueue);
	        logger.log("Producer Created.");
	        
	        producer.send(msg);
	        logger.log("Message sent.");
	        
	        producer.close();
	        logger.log("Producer Closed.");
	        
	        Queue receiveQueue = (Queue) ctx.lookup("jms/ReceiveQueue");
	        logger.log("ReceiveQueue JNDI Obtained.");
	        
	        MessageConsumer consumer = session.createConsumer(receiveQueue);
	        logger.log("Consumer Created.");
	        
	        TextMessage rcvdMsg = (TextMessage) consumer.receive(100);
	        logger.log("Message Received.");
	        
	        if(rcvdMsg != null){
	        	String str = rcvdMsg.getText();
	        	logger.log("Received Message is:" + str);
	        }else{
	        	logger.log("Null message received.");
	        }

	        consumer.close();
	        logger.log("Consumer Closed.");
	        
	        session.close();
	        logger.log("Session Closed.");
	        
	        conn.close();
	        logger.log("Connection Closed.");
	        
	    } catch (Throwable t) {
	       logger.log("Caught Throwable:" + t);
	       
	       t.printStackTrace();
	       
	    }
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
