package com.learning.academy.jms.consumer;

import java.io.IOException;
import java.util.Enumeration;

import javax.annotation.Resource;
import javax.inject.Inject;
import javax.jms.JMSConnectionFactory;
import javax.jms.JMSContext;
import javax.jms.Message;
import javax.jms.Queue;
import javax.jms.QueueBrowser;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.learning.academy.jms.utility.Logger;

/**
 * Servlet implementation class Ex10Consumer
 * 
 * @author nbrprakash
 */
@WebServlet("/Ex10Consumer")
public class Ex10Consumer extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private Logger logger = null;

	@Resource(mappedName = "jms/ReceiveQueue")
	private Queue receiveQueue;
	
    @Inject
    @JMSConnectionFactory("jms/Ex1QCF")
    private JMSContext jmsContext;
    
	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public Ex10Consumer() {
		super();
		logger = new Logger("Ex10 Consumer");
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.getWriter().append(logger.displayText());
		logger.log("Hello World.");

		try {
			QueueBrowser qBrowser = jmsContext.createBrowser(receiveQueue);
			logger.log("Queue Browser Created.");

			@SuppressWarnings("unchecked")
			Enumeration<Message> msgs = qBrowser.getEnumeration();
			logger.log("Obtained enumeration from Queue Browser.");
			
			while(msgs.hasMoreElements()){
				Message tempMsg = msgs.nextElement(); 
		        System.out.println("Message :"+ tempMsg);
			}
		} catch (Throwable t) {
			logger.log("Caught Throwable:" + t);

			t.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
