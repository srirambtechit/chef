package com.learning.academy.jms.producer;

import java.io.IOException;

import javax.annotation.Resource;
import javax.inject.Inject;
import javax.jms.JMSConnectionFactory;
import javax.jms.JMSContext;
import javax.jms.JMSProducer;
import javax.jms.Queue;
import javax.jms.TextMessage;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.learning.academy.jms.utility.Logger;

/**
 * Servlet implementation class Ex10Producer
 * 
 * @author nbrprakash
 */
@WebServlet("/Ex10Producer")
public class Ex10Producer extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private Logger logger = null;
	
    @Inject
    @JMSConnectionFactory("jms/Ex1QCF")
    private JMSContext jmsContext;
    

	@Resource(mappedName = "jms/SendQueue")
	private Queue sendQueue;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public Ex10Producer() {
		super();
		logger = new Logger("Ex10 Producer");
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		logger.log("Hello World.");

		try {
			String text = "Message to be sent";

			JMSProducer producer = jmsContext.createProducer();
			logger.log("Producer Created.");

			TextMessage msg = jmsContext.createTextMessage("Message From Producer ->" + text);
			logger.log("Text Message Created.");

			msg.setJMSCorrelationID("ABC");
			msg.setStringProperty("sport", "cricket");
			logger.log("JMS Priority Set.");
			
			producer.send(sendQueue, msg);
			logger.log("Message sent.");

		} catch (Throwable t) {
			logger.log("Caught Throwable:" + t);

			t.printStackTrace();
		}

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
