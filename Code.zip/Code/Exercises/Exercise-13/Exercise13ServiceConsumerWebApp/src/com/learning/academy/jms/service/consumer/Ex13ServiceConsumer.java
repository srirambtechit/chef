package com.learning.academy.jms.service.consumer;

import java.io.IOException;

import javax.annotation.Resource;
import javax.inject.Inject;
import javax.jms.JMSConnectionFactory;
import javax.jms.JMSConsumer;
import javax.jms.JMSContext;
import javax.jms.JMSProducer;
import javax.jms.MapMessage;
import javax.jms.Queue;
import javax.jms.TextMessage;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.learning.academy.jms.utility.Logger;

/**
 * Servlet implementation class Ex13ServiceConsumer
 * 
 * @author nbrprakash
 */
@WebServlet("/Ex13ServiceConsumer")
public class Ex13ServiceConsumer extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private Logger logger = null;

    @Inject
    @JMSConnectionFactory("jms/Set2QCF")
    private JMSContext jmsContext;
    
	@Resource(mappedName = "jms/Set2ReceiveQueue")
	private Queue receiveQueue;
	
	@Resource(mappedName = "jms/Set2SendQueue")
	private Queue sendQueue;
	
    
	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public Ex13ServiceConsumer() {
		super();
		logger = new Logger("Ex13 ServiceConsumer");
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.getWriter().append(logger.displayText());
		logger.log("Hello World.");

		try {
			
			JMSProducer producer = jmsContext.createProducer();
			logger.log("Producer Created.");

			MapMessage msg = jmsContext.createMapMessage();
			msg.setInt("Parameter1", 11);
			msg.setInt("Parameter2", 13);
			logger.log("Map Message Created.");
			
			msg.setJMSReplyTo(receiveQueue);
			logger.log("Set Reply To Queue.");

			producer.send(sendQueue, msg);
			logger.log("Service Request sent.");
			

			
			JMSConsumer consumer = jmsContext.createConsumer(receiveQueue);
			logger.log("Consumer Created.");

			TextMessage rcvdMsg = (TextMessage) consumer.receive();
			logger.log("Service Response Received.");
			
			if (rcvdMsg != null) {
				logger.log("Received response is:" + rcvdMsg.getText());				
			} else {
				logger.log("Null message received.");
			}
		} catch (Throwable t) {
			logger.log("Caught Throwable:" + t);

			t.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
