package com.learning.academy.jms.service.provider;

import java.io.IOException;

import javax.annotation.Resource;
import javax.inject.Inject;
import javax.jms.JMSConnectionFactory;
import javax.jms.JMSConsumer;
import javax.jms.JMSContext;
import javax.jms.JMSProducer;
import javax.jms.MapMessage;
import javax.jms.Queue;
import javax.jms.TextMessage;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.learning.academy.jms.utility.Logger;

/**
 * Servlet implementation class Ex15ServiceProvider
 * 
 * @author nbrprakash
 */
@WebServlet("/Ex15ServiceProvider")
public class Ex15ServiceProvider extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private Logger logger = null;

    @Inject
    @JMSConnectionFactory("jms/Set2QCF")
    private JMSContext jmsContext;
	
	@Resource(mappedName = "jms/Set2RequestQueue")
	private Queue requestQueue;
	
    
	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public Ex15ServiceProvider() {
		super();
		logger = new Logger("Ex15 ServiceProvider");
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.getWriter().append(logger.displayText());
		logger.log("Hello World.");

		try {
			
			JMSConsumer consumer = jmsContext.createConsumer(requestQueue);
			logger.log("Consumer Created.");

			MapMessage rcvdMsg = (MapMessage) consumer.receive(100);
			logger.log("Service Request Received.");

			int parameter1=0, parameter2=0, sum;
			
			if (rcvdMsg != null) {
				parameter1 = rcvdMsg.getInt("Parameter1");
				parameter2 = rcvdMsg.getInt("Parameter2");
				logger.log("Received Input Data:: Parameter1:" + parameter1 + ", Parameter2:" + parameter2);				
			} else {
				logger.log("Null message received.");
			}
			
			sum = parameter1 + parameter2;
			logger.log("Computed Response is:" + sum);
			
			JMSProducer producer = jmsContext.createProducer();
			logger.log("Producer Created.");

			TextMessage msg = jmsContext.createTextMessage("Service Response ->" + sum);
			logger.log("Text Message Created.");
			
			msg.setJMSCorrelationID(rcvdMsg.getJMSCorrelationID());
			logger.log("JMS CorrelationID set.");
			
			if(rcvdMsg.getStringProperty("sport") != null){
				msg.setStringProperty("sport", rcvdMsg.getStringProperty("sport"));
				logger.log("Message String Property set.");				
			}
			
			producer.send(rcvdMsg.getJMSReplyTo(), msg);
			logger.log("Service Response sent.");
		} catch (Throwable t) {
			logger.log("Caught Throwable:" + t);

			t.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
