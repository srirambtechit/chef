package com.learning.academy.jms.consumer;

import java.io.IOException;

import javax.annotation.Resource;
import javax.inject.Inject;
import javax.jms.JMSConnectionFactory;
import javax.jms.JMSConsumer;
import javax.jms.JMSContext;
import javax.jms.TextMessage;
import javax.jms.Topic;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.learning.academy.jms.utility.Logger;

/**
 * Servlet implementation class Ex16Consumer1
 * 
 * @author nbrprakash
 */
@WebServlet("/Ex16Consumer3")
public class Ex16Consumer3 extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private Logger logger = null;

	@Resource(mappedName = "jms/Set2SubscribeTopic3")
	private Topic subscribeTopic;
	
    @Inject
    @JMSConnectionFactory("jms/Set2TCF")
    private JMSContext jmsContext;
    
	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public Ex16Consumer3() {
		super();
		logger = new Logger("Ex16 Consumer3");
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.getWriter().append(logger.displayText());
		logger.log("Hello World.");

		try {

			JMSConsumer consumer = jmsContext.createConsumer(subscribeTopic);
			logger.log("Consumer Created.");

			TextMessage rcvdMsg = (TextMessage) consumer.receive();
			logger.log("Message Received.");

			if (rcvdMsg != null) {
				String str = rcvdMsg.getText();
				logger.log("Received Message is:" + str);
			} else {
				logger.log("Null message received.");
			}

			consumer.close();
			logger.log("Consumer Closed.");

		} catch (Throwable t) {
			logger.log("Caught Throwable:" + t);

			t.printStackTrace();

		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
