package com.learning.academy.jms.consumer;

import java.io.IOException;

import javax.inject.Inject;
import javax.jms.JMSConnectionFactory;
import javax.jms.JMSContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.learning.academy.jms.utility.Logger;

/**
 * Servlet implementation class Ex18Consumer1
 * 
 * @author nbrprakash
 */
@WebServlet("/Ex19Unsubscribe")
public class Ex19Unsubscribe extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private Logger logger = null;
	
    @Inject
    @JMSConnectionFactory("jms/Set2TCF")
    private JMSContext jmsContext;
    
	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public Ex19Unsubscribe() {
		super();
		logger = new Logger("Ex19 Unsubscribe");
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.getWriter().append(logger.displayText());
		logger.log("Hello World.");

		try {

			jmsContext.unsubscribe("Ex19SharedDurable");			
			logger.log("Subscription Unsubscribed.");

		} catch (Throwable t) {
			logger.log("Caught Throwable:" + t);

			t.printStackTrace();

		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
