package com.learning.academy.jms.consumer;

import java.io.IOException;

import javax.jms.Connection;
import javax.jms.MessageConsumer;
import javax.jms.Queue;
import javax.jms.QueueConnectionFactory;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.learning.academy.jms.utility.Logger;

/**
 * Servlet implementation class Ex3Consumer
 * 
 * @author nbrprakash 
 */
@WebServlet("/Ex3Consumer")
public class Ex3Consumer extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private Logger logger = null;
	
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Ex3Consumer() {
        super();
		logger = new Logger("Ex3 Consumer");
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.getWriter().append(logger.displayText());
		logger.log("Hello World.");
		
		try {
			Context ctx = new InitialContext();
			
			QueueConnectionFactory qcf = (QueueConnectionFactory) ctx.lookup("jms/Ex1QCF");
			logger.log("QCF JNDI Obtained.");
			
			Connection conn = qcf.createQueueConnection();
			logger.log("Connection Created.");
			
	        Session session = conn.createSession();
	        logger.log("Session Created.");
	        
	        conn.start();
	        logger.log("Connection Started.");

	        Queue receiveQueue = (Queue) ctx.lookup("jms/ReceiveQueue");
	        logger.log("ReceiveQueue JNDI Obtained.");
	        
	        MessageConsumer consumer = session.createConsumer(receiveQueue);
	        logger.log("Consumer Created.");
	        
	        TextMessage rcvdMsg = (TextMessage) consumer.receive(100);
	        logger.log("Message Received.");
	        
	        if(rcvdMsg != null){
	        	String str = rcvdMsg.getText();
	        	logger.log("Received Message is:" + str);
	        }else{
	        	logger.log("Null message received.");
	        }
	        
			consumer.close();
			logger.log("Consumer Closed.");
			
	        session.close();
	        logger.log("Session Closed.");
	        
	        conn.close();
	        logger.log("Connection Closed.");
	        
	    } catch (Throwable t) {
	       logger.log("Caught Throwable:" + t);
	       
	       t.printStackTrace();
	       
	    }
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
