package com.learning.academy.jms.producer;

import java.io.IOException;

import javax.jms.Connection;
import javax.jms.MessageProducer;
import javax.jms.Queue;
import javax.jms.QueueConnectionFactory;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.learning.academy.jms.utility.Logger;

/**
 * Servlet implementation class Ex3Producer
 * 
 * @author nbrprakash
 */
@WebServlet("/Ex3Producer")
public class Ex3Producer extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private Logger logger = null;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public Ex3Producer() {
		super();
		logger = new Logger("Ex3 Producer");
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.getWriter().append(logger.displayText());
		logger.log("Hello World.");

		try {
			String text = "Message to be sent";

			Context ctx = new InitialContext();

			QueueConnectionFactory qcf = (QueueConnectionFactory) ctx.lookup("jms/Ex1QCF");
			logger.log("QCF JNDI Obtained.");

			Connection conn = qcf.createQueueConnection();
			logger.log("Connection Created.");

			Session session = conn.createSession();
			logger.log("Session Created.");

			Queue sendQueue = (Queue) ctx.lookup("jms/SendQueue");
			logger.log("SendQueue JNDI Obtained.");

			conn.start();
			logger.log("Connection Started.");

			TextMessage msg = session.createTextMessage("Message From Producer ->" + text);
			logger.log("Text Message Created.");

			MessageProducer producer = session.createProducer(sendQueue);
			logger.log("Producer Created.");

			producer.send(msg);
			logger.log("Message sent.");

	        producer.close();
	        logger.log("Producer Closed.");
	        
			session.close();
			logger.log("Session Closed.");

			conn.close();
			logger.log("Connection Closed.");

		} catch (Throwable t) {
			logger.log("Caught Throwable:" + t);

			t.printStackTrace();

		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
