package com.learning.academy.jms.consumer;

import java.io.IOException;

import javax.annotation.Resource;
import javax.jms.Connection;
import javax.jms.MessageConsumer;
import javax.jms.Queue;
import javax.jms.QueueConnectionFactory;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.learning.academy.jms.utility.Logger;

/**
 * Servlet implementation class Ex4Consumer
 * 
 * @author nbrprakash
 */
@WebServlet("/Ex4Consumer")
public class Ex4Consumer extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private Logger logger = null;

	@Resource(mappedName = "jms/ReceiveQueue")
	private Queue receiveQueue;

	@Resource(mappedName = "jms/Ex1QCF")
	private QueueConnectionFactory qcf;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public Ex4Consumer() {
		super();
		logger = new Logger("Ex4 Consumer");
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.getWriter().append(logger.displayText());
		logger.log("Hello World.");

		try {
			Connection conn = qcf.createQueueConnection();
			logger.log("Connection Created.");

			Session session = conn.createSession();
			logger.log("Session Created.");

			conn.start();
			logger.log("Connection Started.");

			MessageConsumer consumer = session.createConsumer(receiveQueue);
			logger.log("Consumer Created.");

			TextMessage rcvdMsg = (TextMessage) consumer.receive(100);
			logger.log("Message Received.");

			if (rcvdMsg != null) {
				String str = rcvdMsg.getText();
				logger.log("Received Message is:" + str);
			} else {
				logger.log("Null message received.");
			}
			
			consumer.close();
			logger.log("Consumer Closed.");
			
			session.close();
			logger.log("Session Closed.");

			conn.close();
			logger.log("Connection Closed.");

		} catch (Throwable t) {
			logger.log("Caught Throwable:" + t);

			t.printStackTrace();

		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
