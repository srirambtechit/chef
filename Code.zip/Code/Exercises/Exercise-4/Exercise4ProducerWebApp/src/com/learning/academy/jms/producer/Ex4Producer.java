package com.learning.academy.jms.producer;

import java.io.IOException;

import javax.annotation.Resource;
import javax.jms.Connection;
import javax.jms.MessageProducer;
import javax.jms.Queue;
import javax.jms.QueueConnectionFactory;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.learning.academy.jms.utility.Logger;

/**
 * Servlet implementation class Ex4Producer
 * 
 * @author nbrprakash
 */
@WebServlet("/Ex4Producer")
public class Ex4Producer extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private Logger logger = null;

	@Resource(mappedName = "jms/SendQueue")
	private Queue sendQueue;

	@Resource(mappedName = "jms/Ex1QCF")
	private QueueConnectionFactory qcf;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public Ex4Producer() {
		super();
		logger = new Logger("Ex4 Producer");
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.getWriter().append(logger.displayText());
		logger.log("Hello World.");

		try {
			String text = "Message to be sent";

			Connection conn = qcf.createQueueConnection();
			logger.log("Connection Created.");

			Session session = conn.createSession();
			logger.log("Session Created.");

			conn.start();
			logger.log("Connection Started.");

			TextMessage msg = session.createTextMessage("Message From Producer ->" + text);
			logger.log("Text Message Created.");

			MessageProducer producer = session.createProducer(sendQueue);
			logger.log("Producer Created.");

			producer.send(msg);
			logger.log("Message sent.");

			producer.close();
			logger.log("Producer Closed.");

			session.close();
			logger.log("Session Closed.");

			conn.close();
			logger.log("Connection Closed.");

		} catch (Throwable t) {
			logger.log("Caught Throwable:" + t);

			t.printStackTrace();

		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
