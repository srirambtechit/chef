package com.learning.academy.jms.consumer;

import java.io.IOException;

import javax.jms.Connection;
import javax.jms.MessageConsumer;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.jms.Topic;
import javax.jms.TopicConnectionFactory;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.learning.academy.jms.utility.Logger;

/**
 * Servlet implementation class Ex6Consumer
 */
@WebServlet("/Ex6Consumer")
public class Ex6Consumer extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private Logger logger = null;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public Ex6Consumer() {
		super();
		logger = new Logger("Ex6 Consumer");
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.getWriter().append(logger.displayText());
		logger.log("Hello World.");

		try {
			Context ctx = new InitialContext();

			TopicConnectionFactory tcf = (TopicConnectionFactory) ctx.lookup("jms/Ex1TCF");
			logger.log("TCF JNDI Obtained.");

			Connection conn = tcf.createTopicConnection();
			logger.log("Connection Created.");

			Session session = conn.createSession();
			logger.log("Session Created.");

			Topic subscribe1Topic = (Topic) ctx.lookup("jms/Subscribe1Topic");
			logger.log("Subscribe1Topic JNDI Obtained.");

			conn.start();
			logger.log("Connection Started.");

			MessageConsumer consumer = session.createConsumer(subscribe1Topic);
			logger.log("Consumer Created.");

			TextMessage rcvdMsg = (TextMessage) consumer.receive();
			logger.log("Message Received.");

			if (rcvdMsg != null) {
				String str = rcvdMsg.getText();
				logger.log("Received Message in MySecondJMS Program is:" + str);
			} else {
				logger.log("Null message received.");
			}

//			consumer.close();
//			logger.log("Consumer Closed.");
//
//			session.close();
//			logger.log("Session Closed.");
//
//			conn.close();
//			logger.log("Connection Closed.");

		} catch (Throwable t) {
			logger.log("Caught Throwable:" + t);

			t.printStackTrace();

		}

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
