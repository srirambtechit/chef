package com.learning.academy.jms.consumer;

import java.io.IOException;

import javax.annotation.Resource;
import javax.jms.Connection;
import javax.jms.MessageConsumer;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.jms.Topic;
import javax.jms.TopicConnectionFactory;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.learning.academy.jms.utility.Logger;

/**
 * Servlet implementation class Ex7Consumer
 * 
 * @author nbrprakash
 */
@WebServlet("/Ex7Consumer")
public class Ex7Consumer extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private Logger logger = null;
	
    @Resource(mappedName = "jms/Subscribe1Topic")
    private Topic subscribeTopic;
    
    @Resource(mappedName = "jms/Ex1TCF")
    private TopicConnectionFactory tcf;
    
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Ex7Consumer() {
        super();
		logger = new Logger("Ex7 Consumer");
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.getWriter().append(logger.displayText());
		logger.log("Hello World.");

		try {

			Connection conn = tcf.createTopicConnection();
			logger.log("Connection Created.");

			Session session = conn.createSession();
			logger.log("Session Created.");

			conn.start();
			logger.log("Connection Started.");

			MessageConsumer consumer = session.createConsumer(subscribeTopic);
			logger.log("Consumer Created.");

			TextMessage rcvdMsg = (TextMessage) consumer.receive(100);
			logger.log("Message Received.");

			if (rcvdMsg != null) {
				String str = rcvdMsg.getText();
				logger.log("Received Message is:" + str);
			} else {
				logger.log("Null message received.");
			}

			consumer.close();
			logger.log("Consumer Closed.");

			session.close();
			logger.log("Session Closed.");

			conn.close();
			logger.log("Connection Closed.");

		} catch (Throwable t) {
			logger.log("Caught Throwable:" + t);

			t.printStackTrace();

		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
