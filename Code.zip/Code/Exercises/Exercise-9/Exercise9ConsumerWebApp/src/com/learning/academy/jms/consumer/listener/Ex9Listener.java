/**
 * 
 */
package com.learning.academy.jms.consumer.listener;

import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.TextMessage;

/**
 * @author nbrprakash
 *
 */
public class Ex9Listener implements MessageListener {

	/**
	 * 
	 */
	public Ex9Listener() {
		super();
	}

	/* (non-Javadoc)
	 * @see javax.jms.MessageListener#onMessage(javax.jms.Message)
	 */
	@Override
	public void onMessage(Message rcvdMsg) {
		// TODO Auto-generated method stub
		try{
        if((rcvdMsg != null) &&(rcvdMsg instanceof TextMessage)){
        	String str = ((TextMessage)rcvdMsg).getText();
        	System.out.println("Received Message in Listener is:" + str);
        }else{
        	System.out.println("Null message received.");
        }
		}catch(Exception e){
			System.out.println("Caught exception:" + e);
		}

	}

}