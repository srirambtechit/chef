package com.learning.academy.jms.producer;

import java.io.IOException;

import javax.annotation.Resource;
import javax.inject.Inject;
import javax.jms.JMSConnectionFactory;
import javax.jms.JMSContext;
import javax.jms.JMSProducer;
import javax.jms.TextMessage;
import javax.jms.Topic;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.learning.academy.jms.utility.Logger;

/**
 * Servlet implementation class Ex9Producer
 * 
 * @author nbrprakash
 */
@WebServlet("/Ex9Producer")
public class Ex9Producer extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private Logger logger = null;
	
    @Resource(mappedName = "jms/PublishTopic")
    private Topic publishTopic;
    
    @Inject
    @JMSConnectionFactory("jms/Ex1TCF")
    private JMSContext jmsContext;
    
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Ex9Producer() {
        super();
		logger = new Logger("Ex9 Producer");
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.getWriter().append(logger.displayText());
		logger.log("Hello World.");

		try {
			String text = "Message to be sent";

			JMSProducer producer = jmsContext.createProducer();
			logger.log("Producer Created.");

			TextMessage msg = jmsContext.createTextMessage("Message From Producer ->" + text);
			logger.log("Text Message Created.");
			
			producer.send(publishTopic, msg);
			logger.log("Message sent.");

		} catch (Throwable t) {
			logger.log("Caught Throwable:" + t);

			t.printStackTrace();

		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
