package com.learning.academy.jms.queue;

import java.io.IOException;

import javax.annotation.Resource;
import javax.inject.Inject;
import javax.jms.JMSConnectionFactory;
import javax.jms.JMSConsumer;
import javax.jms.JMSContext;
import javax.jms.Message;
import javax.jms.Queue;
import javax.jms.TextMessage;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.learning.academy.jms.utility.Logger;

/**
 * Servlet implementation class QueueClearer
 * 
 * @author nbrprakash
 */
@WebServlet("/QueueClearer")
public class QueueClearer extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private Logger logger = null;

	// @Resource(mappedName = "jms/ReceiveQueue")
	// private Queue receiveQueue;
	//
	// @Inject
	// @JMSConnectionFactory("jms/Ex1QCF")
	// private JMSContext jmsContext;

	@Inject
	@JMSConnectionFactory("jms/Set2QCF")
	private JMSContext jmsContext;

	@Resource(mappedName = "jms/Set2ReceiveQueue")
	private Queue receiveQueue;

	@Resource(mappedName = "jms/Set2SendQueue")
	private Queue sendQueue;

	@Resource(mappedName = "jms/Set2ReplyQueue")
	private Queue replyQueue;

	@Resource(mappedName = "jms/Set2ReplyQueue1")
	private Queue myReplyQueue;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public QueueClearer() {
		super();
		logger = new Logger("QueueClearer");
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.getWriter().append(logger.displayText());
		logger.log("Hello World.");
		Queue tempQueue = myReplyQueue;

			try {

				JMSConsumer consumer = jmsContext.createConsumer(tempQueue);
				logger.log("Consumer Created.");
				Message rcvdMsg = null;
				int iCounter =-1;
				do {
					iCounter++;
					rcvdMsg = consumer.receive(100);
				} while (rcvdMsg != null);
				logger.log("Removed Messages Count:" + iCounter);
			} catch (Throwable t) {
				logger.log("Caught Throwable:" + t);

				t.printStackTrace();
			}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
