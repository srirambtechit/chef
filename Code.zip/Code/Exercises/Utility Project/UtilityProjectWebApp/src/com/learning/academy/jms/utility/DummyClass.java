/**
 * 
 */
package com.learning.academy.jms.utility;

import javax.enterprise.context.RequestScoped;

/**
 * @author nbrpr
 *
 */
@RequestScoped
public class DummyClass {

	/**
	 * 
	 */
	public DummyClass() {
		// TODO Auto-generated constructor stub
	}

}
