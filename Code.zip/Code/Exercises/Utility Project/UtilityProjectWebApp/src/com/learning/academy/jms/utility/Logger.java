/**
 * 
 */
package com.learning.academy.jms.utility;

/**
 * @author nbrprakash
 *
 */
public class Logger {
	
	private String servletName;
	private String logHeader;

	/**
	 * @param servletName 
	 * 
	 */
	public Logger(String servletName) {
		this.servletName = servletName;
		this.logHeader = servletName + " ";
	}

	public String displayText(){
		return "The servlet " + servletName + " is working.";
	}
	
	public void log(String logMsg){
		System.out.println(this.logHeader + logMsg);
	}
}
